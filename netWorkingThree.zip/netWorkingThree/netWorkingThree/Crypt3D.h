//
//  Crypt3D.h
//  BnPlus
//
//  Created by sgs on 15/8/9.
//  Copyright (c) 2015年 Sgs. All rights reserved.
//

#import <Foundation/Foundation.h>

#import <CommonCrypto/CommonDigest.h>
#import <CommonCrypto/CommonCryptor.h>
#import <Security/Security.h>

#import "GTMBase64.h"

@interface Crypt3D : NSObject

+ (NSString *) TripleDES:(NSString*)plainText encryptOrDecrypt:(CCOperation)encryptOrDecrypt;

@end
