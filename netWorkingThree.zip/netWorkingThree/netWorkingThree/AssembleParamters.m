//
//  AssembleParamters.m
//  BnPlus
//
//  Created by sgs on 15/8/9.
//  Copyright (c) 2015年 Sgs. All rights reserved.
//
#import "NSString+MD5Addition.h"
#define ENCRPYT_KEY @"LY!QAZ#EDC%TGB%UJM67OL5@WSX$RFV^YHN*IK43"
#import "Crypt3D.h"
#import "SBJson.h"
#import "AssembleParamters.h"

static AssembleParamters *assembleParas = nil;

@implementation AssembleParamters

+ (AssembleParamters *) shareAssembleParaInstance {
    assembleParas = [[AssembleParamters alloc] init];
    if (assembleParas) {
        return assembleParas;
    }
    
    return nil;
}

- (id) init {
    self = [super init];
    if (self) {
        
    }
    return self;
}

- (NSMutableDictionary *) getRequestParamters:(NSDictionary *)paramters {
    NSMutableDictionary *dictParamters = [[NSMutableDictionary alloc] init];
    
    // 设置共有的参数(必须要传入的)
    [dictParamters setObject:@"0" forKey:@"ostype"];  // 设置系统类型 （公用基本参数）
    [dictParamters setObject:@"1.0" forKey:@"ver"];   // 设置版本号   （公用基本参数）
    [dictParamters setObject:@"0" forKey:@"apptype"]; // 设置应用类型 （公用基本参数）
    
    // 获取当前时间戳
    NSDate *nowDate = [NSDate date];
    NSTimeInterval timeInterval = [nowDate timeIntervalSince1970];
    NSString *currentTimeInterval = [NSString stringWithFormat:@"%0.0f", timeInterval];

//    NSString *currentTimeInterval = [Common getCurrentDateTimeInterval];
    [dictParamters setObject:currentTimeInterval forKey:@"time"];  // 设置时间戳 （公用基本参数）
    
    // 将自己传入的参数从字典转换成字符串
    NSString *afferentPara = [paramters JSONRepresentation];
    /**************/
    /**/
    // 将自己传入的参数经过Crypt3D进行加密 转换成data参数
    NSString *data = [Crypt3D TripleDES:afferentPara encryptOrDecrypt:kCCEncrypt];
    [dictParamters setObject:data forKey:@"data"]; 
     /**/
    // 设置data参数 (自己传入的)
//    [dictParamters setObject:afferentPara forKey:@"data"];
    /*******************/
    // 生成hash加密字符串（将时间戳、data参数和默认加密key拼接成一个字符串 然后通过md5加密得到hash）
    /***********/
    /**/
    NSString *strKeys = [NSString stringWithFormat:@"%@%@%@", currentTimeInterval, data, ENCRPYT_KEY];
     /**/
//     NSString *strKeys = [NSString stringWithFormat:@"%@%@%@", currentTimeInterval, afferentPara, ENCRPYT_KEY];
    /***********/
    
    /**********/
    /**/
    NSString *hash = [strKeys stringFromMD5];
    [dictParamters setObject:hash forKey:@"hash"];      // 设置hash参数 （公用基本参数）
     /**/
//    [dictParamters setObject:strKeys forKey:@"hash"];
    /**********/
    
    
    return dictParamters;
}

@end
