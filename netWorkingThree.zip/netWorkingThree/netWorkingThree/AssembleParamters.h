//
//  AssembleParamters.h
//  BnPlus
//
//  Created by sgs on 15/8/9.
//  Copyright (c) 2015年 Sgs. All rights reserved.
//
//  功能：组装参数
//

#import <Foundation/Foundation.h>

@interface AssembleParamters : NSObject

+ (AssembleParamters *) shareAssembleParaInstance;

- (NSMutableDictionary *) getRequestParamters:(NSDictionary *)paramters;

@end
