//
//  ViewController.m
//  netWorkingThree
//
//  Created by 密码123 on 16/10/25.
//  Copyright © 2016年 密码123. All rights reserved.
//
#import "SBJson.h"
#import "AssembleParamters.h"
#import "ViewController.h"
@interface ViewController ()
{
    UIWebView *webView;
}
@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    
    webView = [[UIWebView alloc] initWithFrame:CGRectMake(0, 0, 320, 480)];
    webView.backgroundColor=[UIColor redColor];
    NSURLRequest *request =[NSURLRequest requestWithURL:[NSURL URLWithString:@"http://www.baidu.com"]];
    [self.view addSubview: webView];
    [webView loadRequest:request];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(notifi:) name:AFNetworkingReachabilityDidChangeNotification object:nil];
    [self networking];

}

- (void)notifi:(NSNotification *)noti{
    
    NSDictionary *dic = noti.userInfo;
    //获取网络状态
    NSInteger status = [[dic objectForKey:@"AFNetworkingReachabilityNotificationStatusItem"] integerValue];
    
    switch (status) {
        case AFNetworkReachabilityStatusNotReachable:{
            
            NSLog(@"无网络连接");
        }
            break;
        case AFNetworkReachabilityStatusReachableViaWWAN:{
            
            NSLog(@"移动蜂窝网络");
        }
            break;
        case AFNetworkReachabilityStatusReachableViaWiFi:{
            
            NSLog(@"wifi网络");
        }
            break;
        case AFNetworkReachabilityStatusUnknown:{
            
            NSLog(@"无法获取网络状态");
        }
            break;
        default:
            break;
    }
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)networking
{
    NSDictionary *paraneters = @{@"mobile":@"18676758514",@"pwd":@"111111",@"allyid":@"1000013"};
    NSMutableDictionary *parameters = [[AssembleParamters shareAssembleParaInstance] getRequestParamters:paraneters];
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    NSString *strUrl=@"http://api.quickwinner.cn/Activity/VerifyLogin";
    manager.responseSerializer.acceptableContentTypes = [manager.responseSerializer.acceptableContentTypes setByAddingObject:@"text/html"];
    manager.requestSerializer = [AFHTTPRequestSerializer serializer];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    [manager POST:strUrl parameters:parameters progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        NSString *responseString =  [[NSString alloc]initWithData:(NSData *)responseObject encoding:NSUTF8StringEncoding];
        NSDictionary *dictResponse = (NSDictionary *)[responseString JSONValue];
        
        NSLog(@"dictResponse----%@",dictResponse);
        
        UIAlertView *alert=[[UIAlertView alloc]initWithTitle:[[dictResponse objectForKey:@"data"] objectForKey:@"RealName"] message:[dictResponse objectForKey:@"msg"] delegate:nil cancelButtonTitle:@"取消" otherButtonTitles:nil, nil];
        [alert show];
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        
    }];
  
    
}

@end
