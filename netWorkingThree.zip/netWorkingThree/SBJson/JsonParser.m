/*********************************************************************
 * 版权所有 (C)2011中兴软件技术(南昌)有限公司
 * 
 * 文件名称： JsonParser.h
 * 文件标识： 
 * 内容摘要： json解析
 * 其它说明： 
 * 当前版本： 
 * 作   者：陈勇
 * 完成日期： 2012年2月12日
 **********************************************************************/


/*************************************************************************** 
 *                                文件引用 
 ***************************************************************************/ 
#import "JsonParser.h"
#import "JSON.h"

@implementation JsonParser


/*************************************************************************** 
 *                                 宏定义 
 ***************************************************************************/ 


/*************************************************************************** 
 *                                 常量 
 ***************************************************************************/ 


/*************************************************************************** 
 *                                类型定义 
 ***************************************************************************/ 


/*************************************************************************** 
 *                                全局变量 
 ***************************************************************************/ 
JsonParser *g_pParser = nil;


/*************************************************************************** 
 *                                 原型 
 ***************************************************************************/ 


/*************************************************************************** 
 *                               类的实现 
 ***************************************************************************/ 


/***********************************************************************
 * 方法名称： init
 * 功能描述： 构造函数，dataArray初始化
 * 输入参数： 
 * 输出参数： 
 * 返 回 值： 
 * 其它说明： 
 ***********************************************************************/
- (id)init
{
	if (self = [super init])
	{
		m_pMulArrayData = [[NSMutableArray alloc] init];
	}
    
    g_pParser = self;
	
	return self;
}


/***********************************************************************
 * 方法名称： getInstance
 * 功能描述： 获取实例
 * 输入参数： 
 * 输出参数： 
 * 返 回 值： 
 * 其它说明： 
 ***********************************************************************/
+ (JsonParser *)getInstance
{
    return g_pParser;
}


/***********************************************************************
 * 方法名称： dataAnalyse
 * 功能描述： JSON数据解析
 * 输入参数： (NSString *)tempData，从服务器接受的JSON数据；
 * 输出参数： 
 * 返 回 值： 
 * 其它说明： 
 ***********************************************************************/
- (void)dataAnalyse:(NSString *)tempData
{
	/*对形参进行检测*/
	if (tempData == nil)
	{
		return ;
	}
	
	/*解析数据，并获取解析后的值*/
	m_pMulDicData = [tempData JSONValue]; 
	//[m_pMulDicData retain];
}


/***********************************************************************
 * 方法名称： getData
 * 功能描述： 获取JSON数据解析后的数据
 * 输入参数： 
 * 输出参数： 
 * 返 回 值：（NSMutableDictionary *)类型，解析后的数据 
 * 其它说明： 
 ***********************************************************************/
- (NSMutableDictionary *)getData
{
	return m_pMulDicData;
}


/***********************************************************************
 * 方法名称： getData
 * 功能描述： 获取JSON数据解析后的数据
 * 输入参数： 
 * 输出参数： 
 * 返 回 值：（NSMutableDictionary *)类型，解析后的数据 
 * 其它说明： 
 ***********************************************************************/
- (NSMutableDictionary *)getData:(NSString *)strDataBeforeParser
{    
    if (strDataBeforeParser == nil)
    {
        return nil;
    }
    
    /*解析数据，并获取解析后的值*/
	return [strDataBeforeParser JSONValue];
}


/***********************************************************************
 * 方法名称： getDataArray
 * 功能描述： 获取JSON数据解析后的数据
 * 输入参数： 
 * 输出参数： 
 * 返 回 值：（NSMutableDictionary *)类型，解析后的数据 
 * 其它说明： 
 ***********************************************************************/
- (NSMutableArray *)getDataArray
{
	
	if (nil == m_pMulArrayData) 
	{
		m_pMulArrayData = [[NSMutableArray alloc] init];
	}
	else 
	{
		if ([m_pMulArrayData count] > 0) 
		{
			[m_pMulArrayData removeAllObjects];
		}
	}

	
	/* 用于存放所有数据value值 */
	NSMutableArray *tempArray = [[NSMutableArray alloc] init];
	
	/* 用于存放字典的key值 */
	NSMutableArray *tempKeyArray = [[NSMutableArray alloc] init];
	
	/* 用于存放解析头 */
	NSMutableDictionary *titleDict = [[NSMutableDictionary alloc] init];
	for (id key in m_pMulDicData) 
	{
		id value = [m_pMulDicData objectForKey:key];
		if ([value isKindOfClass:[NSString class]]) 
		{
			[titleDict setObject:value forKey:key];
		}
		if ([value isKindOfClass:[NSNumber class]]) 
		{
			NSString *temp = [NSString stringWithFormat:@"%d", [value intValue]];
			[titleDict setObject:temp forKey:key];
		}
		if ([value isKindOfClass:[NSArray class]] ||
			
			[value isKindOfClass:[NSMutableArray class]]) 
		{
			[tempArray addObject:value];
			[tempKeyArray addObject:key];
		}
		
	}

	/* 将数据头添加进数组中 */
    if ([titleDict count] > 0)
    {
        [m_pMulArrayData addObject:titleDict];
    }
	[titleDict release];
	
	/* 若返回的数据有值 */
	if ([tempArray count] > 0) 
	{
		for (int i = 0; i < [[tempArray objectAtIndex:0] count]; i++) 
		{
			NSMutableDictionary *tempDict = [[NSMutableDictionary alloc] init];
			for (int j = 0; j < [tempArray count ]; j++) 
			{
				id tempString = [[tempArray objectAtIndex:j] objectAtIndex:i];
				id tempKey = [tempKeyArray objectAtIndex:j];
				[tempDict setObject:tempString forKey:tempKey];
			}

			[m_pMulArrayData addObject:tempDict];
			[tempDict release];
		}
		
	}

	[tempArray release];
	[tempKeyArray release];
	
	return m_pMulArrayData;
}


/***********************************************************************
 * 方法名称： getDataArray
 * 功能描述： 获取JSON数据解析后的数据
 * 输入参数： 
 * 输出参数： 
 * 返 回 值：（NSMutableDictionary *)类型，解析后的数据 
 * 其它说明： 
 ***********************************************************************/
- (NSMutableArray *)getDataArray:(NSString *)strDataBeforeParser
{
    if (strDataBeforeParser == nil)
    {
        return nil;
    }
	
    // 清空原来数据
	if (nil == m_pMulArrayData) 
	{
		m_pMulArrayData = [[NSMutableArray alloc] init];
	}
	else 
	{
		if ([m_pMulArrayData count] > 0) 
		{
			[m_pMulArrayData removeAllObjects];
		}
	}
	
    /*解析数据，并获取解析后的值*/
    
	id pPaserData = [strDataBeforeParser JSONValue]; 
    
    if (pPaserData == nil)
    {
        return nil;
    }
    
    /* 如果是数组直接返回 */
    if ([pPaserData isKindOfClass:[NSArray class]])
    {
        return pPaserData;
    }
    
    NSMutableDictionary *pDic = (NSMutableDictionary *)pPaserData;    
    
	/* 用于存放所有数据value值 */
	NSMutableArray *tempArray = [[NSMutableArray alloc] init];
	
	/* 用于存放字典的key值 */
	NSMutableArray *tempKeyArray = [[NSMutableArray alloc] init];
	
	/* 用于存放解析头 */
	NSMutableDictionary *titleDict = [[NSMutableDictionary alloc] init];
	for (id key in pDic) 
	{
		id value = [pDic objectForKey:key];
		if ([value isKindOfClass:[NSString class]]) 
		{
			[titleDict setObject:value forKey:key];
		}
		if ([value isKindOfClass:[NSNumber class]])
		{
			NSString *temp = [NSString stringWithFormat:@"%d", [value intValue]];
			[titleDict setObject:temp forKey:key];
		}
		if ([value isKindOfClass:[NSArray class]] ||
			
			[value isKindOfClass:[NSMutableArray class]]) 
		{
			[tempArray addObject:value];
			[tempKeyArray addObject:key];
		}
        if ([value isKindOfClass:[NSDictionary class]])
        {
            // 字典直接添加到数组里
            NSMutableDictionary *tempDict = [[NSMutableDictionary alloc] initWithCapacity:(NSUInteger)1];
            [tempDict setObject:value forKey:key];
            [m_pMulArrayData addObject:tempDict];
            [tempDict release];
        }
//        else {
//            [titleDict setObject:@"" forKey:key];
//        }
	}
    
	/* 将数据头添加进数组中 */
    if ([titleDict count] > 0)
    {
        [m_pMulArrayData addObject:titleDict];
    }
	[titleDict release];
	
	/* 若返回的数据有值 */
	if ([tempArray count] > 0) 
	{
		for (int i = 0; i < [[tempArray objectAtIndex:0] count]; i++) 
		{
			NSMutableDictionary *tempDict = [[NSMutableDictionary alloc] init];
			for (int j = 0; j < [tempArray count ]; j++) 
			{
				id tempString = [[tempArray objectAtIndex:j] objectAtIndex:i];
				id tempKey = [tempKeyArray objectAtIndex:j];
				[tempDict setObject:tempString forKey:tempKey];
			}
            
			[m_pMulArrayData addObject:tempDict];
			[tempDict release];
		}
		
	}
    
	[tempArray release];
	[tempKeyArray release];
	
	return m_pMulArrayData;
}


/***********************************************************************
 * 方法名称： dealloc
 * 功能描述： 成员变量的释放
 * 输入参数： 
 * 输出参数： 
 * 返 回 值： 
 * 其它说明： 
 ***********************************************************************/
- (void)dealloc 
{
	//[m_pMulDicData release];
	m_pMulDicData = nil;
	
	[m_pMulArrayData release];
	m_pMulArrayData = nil;
    
    g_pParser = nil;
	
    [super dealloc];
	
	//m_pMulDicData = nil;
}

@end
